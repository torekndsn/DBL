	 var conversation = ["Please take a seat and write to me.<br>What should I call you?",
	"Nice to meet you, . <br><br>^500I am curious;^500 do you ever have the feeling that something is lost when we communicate through technology?",
	"Because, you see, I was thinking about typing.<br>^500The result of this action does not reflect its process.<br><br> ^500When you type on a keyboard you don’t simply press key after key, without any hesitation, in a plain flow of letters.^1000 There is so much more happening there than what one may read in the final text.<br><br>^500 Do you see what I’m trying to say?^1000 Perhaps what comes next will clarify it for you...<br><br>^1500Would you like to participate in a small experiment to reveal what of you disappears into the keyboard? ^500Type YES if you read the conditions and agree to share your result anonymously or BACK to return to the home screen.",
	"Great. It’s very simple.<br><br>^500I would like you to answer one question.<br><br>^1000It may be quite personal, so if you don’t feel comfortable just change the question.^1000 Otherwise, do not think too much. Just answer from your heart.<br><br>^500Type GO when you are ready."
	]; 


	var questions =[
		"What is your earliest memory?",
		"Why is your best friend your best friend?",
		"What is the hardest thing that has ever happened to you?",
		"Can you describe your first kiss?",
		"If you could take back one thing you have done in life, what would it be?",
		"What's the last thing that made you cry?",
		"Have you ever broken somebody's heart? How?",
		"What do you wish others would understand better about you?",
		"What makes you feel like home?",
		"If you could change anything about the way you were raised, what would you change?",
		"If you could keep only one memory, what would it be?"
	]
