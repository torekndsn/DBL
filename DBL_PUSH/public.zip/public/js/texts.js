	 var conversation = ["Hi, please take a seat and write to me.<br>^500 What should I call you?",
	"Nice to meet you, . <br>^500I am curious; do you ever have the feeling that something is lost when we communicate through technology?",
	"Because you see,^500 I was thinking about typing.^500 It’s an action that doesn’t reflect the process.<br><br> ^500You just typed your answers to me, but did you hesitate? <br>^500 Did you type that rushing, eager to see the next screen?  <br><br>^1000Would you like to participate in a small test to reveal what of you disappears into the keyboard?<br><br>^500Type YES to start or BACK to return to the home screen."
	]; 


	var questions =[
		"How would you describe your relationship with your mother?",
		"What is your earliest memory?",
		"Why is your best friend your best friend?",
		"What is the hardest thing that has ever happened to you?",
		"Can you describe your first kiss?",
		"Which parent are you closer to and why?",
		"If you could take back one thing you have done in life, what would it be?",
		"What's the last thing that made you cry?",
		"What's the stupidest thing you have ever done?",
		"Have you ever broken somebody's heart? How?",
		"What do you wish others would understand better about you?",
		"What makes you feel like home?",
		"If you could change anything about the way you were raised, what would you change?",
		"If you could keep only one memory, what would it be?"
	]
